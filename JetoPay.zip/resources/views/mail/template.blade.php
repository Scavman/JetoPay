<h2>Name: {{ $name_input, ' '. $surname_input }}</h2>
<h3>Email Address: {{ $email_input }}</h3>
<h3>Phone Number: {{ $phone_number_input }}</h3>
<h3>Company Name: {{ $company_name_input }}</h3>
<h3>Country of Incorporation: {{ $country_of_incorporation }}</h3>
<h3>Company Website: {{ $company_website_input }}</h3>
<h3>Monthly Card Processing Volume: {{ $monthly_card_input }}</h3>
<h3>Industry: {{ $industry_input }}</h3>
<div>Content: {{ $content_input }}</div>


{{--
public string $name_input,
public string $surname_input,
public string $position_input,
public string $email_input,
public string $phone_number_input,
public string $company_name_input,
public string $country_of_incorporation,
public string $company_website_input,
public string $monthly_card_input,
public string $industry_input,
public string $content_input--}}
